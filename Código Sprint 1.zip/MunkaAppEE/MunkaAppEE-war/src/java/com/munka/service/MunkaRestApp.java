package com.munka.service;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author Felipe Dourado e Leonardo Ferreira
 *
 */
@ApplicationPath("rest")
public class MunkaRestApp extends Application {

}
